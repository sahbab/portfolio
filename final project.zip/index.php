
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Portfolio | Sahba Bahizad</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head>

<body>
<!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
               
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="portfolio.html">Portfolio</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li class="login">
                            <a  href="login.php"><i class="icon-lock"></i></a>
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
            </div>
        </div>
    </header>
    <!-- /header -->
	
    <section class="title">
        <div class="container">
            <div class="row-fluid">
                <div class="span6">
                    <h1>Sahba Bahizad</h1>
                </div>
				
            </div>
        </div>
    </section>
    <!-- / .title -->

    <section id="about-us" class="container main">
        <div class="row-fluid">
			<div class="span6">
                <div class="box">
                    <p><img src="images/sahba.jpg" alt="" ></p>
                    <h5>Sahba Bahizad</h5>
                    <p>I believe that one's life is fruitful when it is served on helping and solving one's problem.
					I have found myself enjoying problem solving as well as building new products that are useful and can help optimizing user's time and effort.
					</p>
                    <a class="btn btn-social btn-linkedin" href="mailto: s.bahizad@mail.com">
						<i class="icon-envelope"></i></a>
					<!--<a class="btn btn-social btn-google-plus" href="#">
						<i class="icon-google-plus"></i></a>
					<a class="btn btn-social btn-twitter" href="#">
						<i class="icon-twitter"></i></a>-->
					<a class="btn btn-social btn-linkedin" href="https://www.linkedin.com/in/sahba-bahizad-18971a6a" target="_blank">
						<i class="icon-linkedin"></i></a>
					<a class="btn btn-social btn-linkedin" href="https://github.com/sahbab/portfolio" target="_blank">
						<i class="icon-github"></i></a>
                </div>
            </div>
            <!--<div class="span6">
                <h2>What we are</h2>
                <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris in erat justo. Nullam ac urna eu felis dapibus condimentum sit amet a augue. Sed non neque elit. Sed ut imperdiet nisi. Proin condimentum fermentum nunc. Etiam pharetra, erat sed fermentum feugiat, velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.</p>
            </div>-->
            <div class="span6">
                <h2>My Skills</h2>
                <div>
                    <div class="progress"><div class="bar" style="width: 70%; text-align:left; padding-left:10px;">Java</div></div>
                     <div class="progress progress-info"><div class="bar" style="width: 80%; text-align:left; padding-left:10px;">SQL Server/ MySQL</div></div>
                    <div class="progress progress-danger"><div class="bar" style="width: 97%; text-align:left; padding-left:10px;">Microsoft Office(Excel, Word, Outlook, Power Point)</div></div>
                    <div class="progress progress-warning"><div class="bar" style="width: 85%; text-align:left; padding-left:10px;">HTML & CSS </div></div>
                    <div class="progress progress-"><div class="bar" style="width: 25%; text-align:left; padding-left:10px;">JQuery</div></div>
                    <div class="progress progress-warning"><div class="bar" style="width: 55%; text-align:left; padding-left:10px;">PHP </div></div>
                    <div class="progress progress"><div class="bar" style="width: 45%; text-align:left; padding-left:10px;">JavaScript </div></div>
                     <div class="progress progress-info"><div class="bar" style="width: 80%; text-align:left; padding-left:10px;">Report Studio/Framework Manager</div></div>
                    <div class="progress progress-danger"><div class="bar" style="width: 93%; text-align:left; padding-left:10px;">Dimentional Data Modeling</div></div>

                </div>
            </div>
        </div>

        <hr>

	</section>

<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
    <div class="container">

        <!--row-fluids-->
        <div class="row-fluid">

            <!--Contact Form-->
            <div class="span3">
                <h4>ADDRESS</h4>
                <ul class="unstyled address">
                    <li>
                        <i class="icon-home"></i><strong>Address:</strong> Renton, WA 98058
                    </li>
                    <li>
                        <i class="icon-envelope"></i>
                        <strong>Email: </strong><a href="mailto: s.bahizad@gmail.com">s.bahizad@gmail.com</a>
                    </li>
                    <!--<li>
                        <i class="icon-globe"></i>
                        <strong>Website:</strong> www.domain.com
                    </li>-->
                    <li>
                        <i class="icon-phone"></i>
                        <strong>Phone:</strong> 206-661-5396
                    </li>
                </ul>
            </div>
            <!--End Contact Form-->

    </div>
    <!--/row-fluid-->
</div>
<!--/container-->

</section>
<!--/bottom-->

<!--Footer-->
<footer id="footer">
    <div class="container">
        <div class="row-fluid">
            <div class="span5 cp">
                &copy; 2016 <a target="_blank" href="#" title="Sahba Bahizad">Sahba Bahizad</a>. All Rights Reserved.
            </div>
            <!--/Copyright-->
            <div class="span1">
                <a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a>
            </div>
            <!--/Goto Top-->
        </div>
    </div>
</footer>
<!--/Footer-->

<!--  Login form -->
<div class="modal hide fade in" id="loginForm" aria-hidden="false">
    <div class="modal-header">
        <i class="icon-remove" data-dismiss="modal" aria-hidden="true"></i>
        <h4>Login Form</h4>
    </div>
    <!--Modal Body-->
    <div class="modal-body">
        <form class="form-inline" action="login.php" method="post" id="form-login">
            <input type="text" class="input-small" placeholder="Username">
            <input type="password" class="input-small" placeholder="Password">
            
            <button type="submit" class="btn btn-primary">Sign in</button>
        </form>
        
    </div>
    <!--/Modal Body-->
</div>
<!--  /Login form -->

<script src="js/vendor/jquery-1.9.1.min.js"></script>
<script src="js/vendor/bootstrap.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>
