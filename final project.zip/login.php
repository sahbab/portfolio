<?php
session_start();
# Login.php
// This page processes the login form submission.
// Upon successful login, the user is redirected.
// Two included files are necessary.
// Send NOTHING to the Web browser prior to the setcookie() lines!

// Check if the form has been submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	
	// Need the database connection:
	//
		// For processing the login:
	require ('loginfunction.php');
	require ('../db/db.php');
	// Check the login:
	list ($check, $data) = check_login($cnxn, $_POST['user'], $_POST['pass']);
	
	if ($check) { // OK
		//set sesssions
        $_SESSION['username'] = $_POST['user'];
		// Redirect:
		redirect_user('admin.php');
			
	} else { // Unsuccessful!

		// Assign $data to $errors for error reporting
		// in the login_page.inc.php file.
		$errors = $data;

	}
		
	mysqli_close($cnxn); // Close the database connection.

} // End of the main submit conditional.

// Create the page:
include ('loginPage.php');
?>