<?php
$errors = [];
$missing = [];
if (isset($_POST['send'])) {
    $expected = ['fname', 'lname', 'email', 'comments'];
    $required = ['fname', 'lname', 'email', 'comments'];
    $to = 'Sahba Bahizad <s.bahizad@gmail.com>';
    $subject = 'Feedback from online form';
    $headers = [];
    $headers[] = 'From: Myportfolio@example.com';
    $headers[] = 'Cc: s.bahizad@gmail.com';
    $headers[] = 'Content-type: text/plain; charset=utf-8';
    $authorized = '-fdavid@example.com';
    require './Includes/process_mail.php';
	
    if ($mailSent) {
        header('Location: thanks.php');
		//save in database
    require '../db/db_portfolio.php';
	$fname =$_POST['fname'];
	$lname =$_POST['lname'];
	$email =$_POST['email'];
	$comments =$_POST['comments'];
    $fname = mysqli_real_escape_string($cnxn, $fname);
    $lname = mysqli_real_escape_string($cnxn, $lname);
	$email = mysqli_real_escape_string($cnxn, $email);
    $comments = mysqli_real_escape_string($cnxn, $comments);
     //Write to Database
	 $created_date = date("Y-m-d H:i:s");
        $sql = "INSERT INTO contacts (fname, lname, email, comment , timestamp)
                VALUES ('$fname', '$lname' , '$email', '$comments' ,'$created_date')";
        @mysqli_query($cnxn, $sql)
            or die ("Error executing query: $sql");
        exit;
    }
}

?>
<?
    require '../db/db_portfolio.php';
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Contact</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	<link href="css/styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="nav-collapse collapse pull-right">
				                    <ul class="nav">
				                        <li><a href="index.html">Home</a></li>
				                        <li><a href="portfolio.html">Portfolio</a></li>
				                        <li><a href="contact.php">Contact</a></li>
				                        
				                    </ul>
				                </div><!--/.nav-collapse -->
				            </div>
				        </div>
				    </header>
<!-- /header -->
<section id="contact-page" class="container">
        <div class="row-fluid">

            <div class="span8">
<h1>Contact</h1>
<?php if ($_POST && ($suspect || isset($errors['mailfail']))) : ?>
<p class="warning">Sorry, your mail couldn't be sent.</p>
<?php elseif ($errors || $missing) : ?>
<p class="warning">Please fix the item(s) indicated</p>
<?php endif; ?>
<form method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
  <p>
    <label for="fname">* First Name:
    <?php if ($missing && in_array('fname', $missing)) : ?>
        <span class="warning">Please enter your first name</span>
    <?php endif; ?>
	</label>
    <input type="text" name="fname" id="fname"
        <?php
        if ($errors || $missing) {
            echo 'value="' . htmlentities($fname) . '"';
        }
        ?>
        required>
  </p>
  <p>
	<label for="lname">* Last Name:
    <?php if ($missing && in_array('lname', $missing)) : ?>
        <span class="warning">Please enter your last name</span>
    <?php endif; ?>
    </label>
	<input type="text" name="lname" id="lname"
        <?php
        if ($errors || $missing) {
            echo 'value="' . htmlentities($lname) . '"';
        }
        ?>
        required>
	
  </p>
  <p>
    <label for="email">* Email:
        <?php if ($missing && in_array('email', $missing)) : ?>
            <span class="warning">Please enter your email address</span>
        <?php elseif (isset($errors['email'])) : ?>
            <span class="warning">Invalid email address</span>
        <?php endif; ?>
    </label>
    <input type="email" name="email" id="email"
        <?php
        if ($errors || $missing) {
            echo 'value="' . htmlentities($email) . '"';
        }
         ?>
        required>
  </p>
  <p>
    <label for="comments">Comments:
        <?php if ($missing && in_array('comments', $missing)) : ?>
            <span class="warning">You forgot to add any comments</span>
        <?php endif; ?>
    </label>
      <textarea name="comments" id="comments"><?php
          if ($errors || $missing) {
              echo htmlentities($comments);
          }
          ?></textarea>
  </p>
  <p>
    <input type="submit" name="send" id="send" value="Send Comments">
  </p>
</form>
 </div>

        <div class="span4">
            <h4>Contact Information</h4>
            <p>I will do my best to reply in 24 hours.</p>
            <p>
                <i class="icon-map-marker pull-left"></i>
                WA, 98058,  United States
            </p>
            <p>
                <i class="icon-envelope"></i> &nbsp;<a href="mailto: s.bahizad@gmail.com">s.bahizad@gmail.com</a>
            </p>
            <p>
                <i class="icon-phone"></i> &nbsp;+206 661 5396
            </p>

        </div>

    </div>

</section>
<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
    <div class="container">

        <!--row-fluids-->
        <div class="row-fluid">

            <!--Contact Form-->
            <div class="span3">
                <h4>ADDRESS</h4>
                <ul class="unstyled address">
                    <li>
                        <i class="icon-home"></i><strong>Address:</strong> Renton, WA 98058
                    </li>
                    <li>
                        <i class="icon-envelope"></i>
                        <strong>Email: </strong><a href="mailto: s.bahizad@gmail.com">s.bahizad@gmail.com</a>
                    </li>
                    <!--<li>
                        <i class="icon-globe"></i>
                        <strong>Website:</strong> www.domain.com
                    </li>-->
                    <li>
                        <i class="icon-phone"></i>
                        <strong>Phone:</strong> 206-661-5396
                    </li>
                </ul>
            </div>
            <!--End Contact Form-->

    </div>
    <!--/row-fluid-->
</div>
<!--/container-->

</section>
<!--/bottom-->

<!--Footer-->
<footer id="footer">
    <div class="container">
        <div class="row-fluid">
            <div class="span5 cp">
                &copy; 2016 <a target="_blank" href="#" title="Sahba Bahizad">Sahba Bahizad</a>. All Rights Reserved.
            </div>
            <!--/Copyright-->
            <div class="span1">
                <a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a>
            </div>
            <!--/Goto Top-->
        </div>
    </div>
</footer>
<!--/Footer-->
</body>
</html>